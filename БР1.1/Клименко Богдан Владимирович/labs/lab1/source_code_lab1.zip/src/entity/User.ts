import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, OneToMany } from "typeorm";
import { Post } from "./Post";
import { Like } from "./Like";
import { Comment } from "./Comment";
import { Follow } from "./Follow";
import { Favorite } from "./Favorite";
import { Notification } from "./Notification";

@Entity("users")
export class User {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ unique: true })
  username!: string;

  @Column({ unique: true })
  email!: string;

  @Column()
  passwordHash!: string;

  @Column({ type: "varchar", nullable: true })
  avatarPath!: string | null;

  @CreateDateColumn()
  createdAt!: Date;

  @OneToMany(() => Post, (post) => post.user)
  posts!: Post[];

  @OneToMany(() => Like, (like) => like.user)
  likes!: Like[];

  @OneToMany(() => Comment, (comment) => comment.user)
  comments!: Comment[];

  @OneToMany(() => Follow, (follow) => follow.follower)
  followers!: Follow[];

  @OneToMany(() => Follow, (follow) => follow.following)
  following!: Follow[];

  @OneToMany(() => Favorite, (favorite) => favorite.user)
  favorites!: Favorite[];

  @OneToMany(() => Notification, (notification) => notification.user)
  notifications!: Notification[];
}