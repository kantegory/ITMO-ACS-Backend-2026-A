import "reflect-metadata";
import { DataSource } from "typeorm";
import { User } from "./entity/User";
import { Post } from "./entity/Post";
import { Like } from "./entity/Like";
import { Comment } from "./entity/Comment";
import { Follow } from "./entity/Follow";
import { Favorite } from "./entity/Favorite";
import { Notification } from "./entity/Notification";

export const AppDataSource = new DataSource({
  type: "sqlite",
  database: "database.sqlite",
  synchronize: true,
  logging: false,
  entities: [User, Post, Like, Comment, Follow, Favorite, Notification],
  migrations: [],
  subscribers: [],
});