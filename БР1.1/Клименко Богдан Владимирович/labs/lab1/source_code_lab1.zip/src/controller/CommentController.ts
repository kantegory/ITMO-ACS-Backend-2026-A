import { Response } from "express";
import { AuthRequest } from "../middleware/auth";
import { AppDataSource } from "../data-source";
import { Comment } from "../entity/Comment";
import { Notification } from "../entity/Notification";
import { Post } from "../entity/Post";
import multer from "multer";
import path from "path";
import { ensureUploadDirs, processCommentPhoto } from "../utils/imageProcessor";
import fs from "fs/promises";

const upload = multer({ dest: "uploads/temp/" });

export class CommentController {
  static async addComment(req: AuthRequest, res: Response): Promise<Response> {
    return new Promise((resolve) => {
      const multerUpload = upload.single("photo");
      multerUpload(req as any, res as any, async (err: any) => {
        if (err) {
          resolve(res.status(400).json({ message: err.message }));
          return;
        }
        const { text } = req.body;
        if (!text) {
          resolve(res.status(400).json({ message: "Text is required" }));
          return;
        }
        const userId = req.userId!;
        // 🟢 Безопасное получение postId
        const postIdParam = req.params.postId;
        const postId = typeof postIdParam === 'string' ? parseInt(postIdParam, 10) : parseInt(postIdParam[0], 10);
        if (isNaN(postId)) {
          resolve(res.status(400).json({ message: "Invalid post id" }));
          return;
        }
        const file = (req as any).file;
        let photoPath: string | null = null;
        if (file) {
          try {
            await ensureUploadDirs();
            const ext = path.extname(file.originalname);
            const fileName = `comment_${userId}_${Date.now()}${ext}.jpg`;
            photoPath = await processCommentPhoto(file.path, fileName);
            await fs.unlink(file.path).catch(() => {});
          } catch (error) {
            resolve(res.status(500).json({ message: "Error processing photo" }));
            return;
          }
        }
        const commentRepo = AppDataSource.getRepository(Comment);
        const comment = commentRepo.create({ userId, postId, text, photoPath });
        await commentRepo.save(comment);
        // Уведомление
        const postRepo = AppDataSource.getRepository(Post);
        const post = await postRepo.findOne({ where: { id: postId } });
        if (post && post.userId !== userId) {
          const notifRepo = AppDataSource.getRepository(Notification);
          const notif = notifRepo.create({
            userId: post.userId,
            type: "comment",
            relatedUserId: userId,
            relatedPostId: postId,
          });
          await notifRepo.save(notif);
        }
        resolve(res.status(201).json(comment));
      });
    });
  }

  static async deleteComment(req: AuthRequest, res: Response): Promise<Response> {
    try {
      const userId = req.userId!;
      const commentIdParam = req.params.id;
      const commentId = typeof commentIdParam === 'string' ? parseInt(commentIdParam, 10) : parseInt(commentIdParam[0], 10);
      if (isNaN(commentId)) {
        return res.status(400).json({ message: "Invalid comment id" });
      }
      const commentRepo = AppDataSource.getRepository(Comment);
      const comment = await commentRepo.findOne({ where: { id: commentId } });
      if (!comment) return res.status(404).json({ message: "Comment not found" });
      if (comment.userId !== userId) {
        return res.status(403).json({ message: "Not your comment" });
      }
      if (comment.photoPath) {
        const fullPath = path.join(process.cwd(), comment.photoPath);
        await fs.unlink(fullPath).catch(() => {});
      }
      await commentRepo.remove(comment);
      return res.json({ message: "Comment deleted" });
    } catch (error) {
      return res.status(500).json({ message: "Internal error" });
    }
  }

  static async getCommentsByPost(req: AuthRequest, res: Response): Promise<Response> {
    try {
      const postIdParam = req.params.postId;
      const postId = typeof postIdParam === 'string' ? parseInt(postIdParam, 10) : parseInt(postIdParam[0], 10);
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post id" });
      }
      const commentRepo = AppDataSource.getRepository(Comment);
      const comments = await commentRepo.find({
        where: { postId },
        relations: ["user"],
        order: { createdAt: "ASC" },
      });
      return res.json(comments);
    } catch (error) {
      return res.status(500).json({ message: "Internal error" });
    }
  }
}