import { Response } from "express";
import { AuthRequest } from "../middleware/auth";
import { AppDataSource } from "../data-source";
import { Post } from "../entity/Post";
import { Like } from "../entity/Like";
import { Favorite } from "../entity/Favorite";
import { User } from "../entity/User";
import { Follow } from "../entity/Follow";
import { Notification } from "../entity/Notification";
import multer from "multer";
import path from "path";
import { ensureUploadDirs, processPostPhoto } from "../utils/imageProcessor";
import fs from "fs/promises";

const upload = multer({ dest: "uploads/temp/" });

function parseIdParam(param: string | string[]): number | null {
  const str = Array.isArray(param) ? param[0] : param;
  const id = parseInt(str, 10);
  return isNaN(id) ? null : id;
}

export class PostController {
  static async createPost(req: AuthRequest, res: Response): Promise<Response> {
    return new Promise((resolve) => {
      const multerUpload = upload.single("photo");
      multerUpload(req as any, res as any, async (err: any) => {
        if (err) {
          resolve(res.status(400).json({ message: err.message }));
          return;
        }
        const file = (req as any).file;
        if (!file) {
          resolve(res.status(400).json({ message: "Photo required" }));
          return;
        }
        const description = req.body.description || null;
        try {
          await ensureUploadDirs();
          const baseName = `${req.userId}_${Date.now()}`;
          const { originalPath, previewPath } = await processPostPhoto(file.path, baseName);
          const postRepo = AppDataSource.getRepository(Post);
          const post = postRepo.create({
            userId: req.userId!,
            originalPhotoPath: originalPath,
            previewPhotoPath: previewPath,
            description,
          });
          await postRepo.save(post);
          await fs.unlink(file.path).catch(() => {});
          resolve(res.status(201).json(post));
        } catch (error) {
          console.error("Create post error:", error);
          resolve(res.status(500).json({ message: "Internal error" }));
        }
      });
    });
  }

  static async getFeed(req: AuthRequest, res: Response): Promise<Response> {
    try {
      const userId = req.userId!;
      const followRepo = AppDataSource.getRepository(Follow);
      const follows = await followRepo.find({ where: { followerId: userId } });
      const followingIds = follows.map((f) => f.followingId);
      const postRepo = AppDataSource.getRepository(Post);
      let posts;
      if (followingIds.length === 0) {
        posts = await postRepo.find({ order: { createdAt: "DESC" }, relations: ["user"] });
      } else {
        posts = await postRepo
          .createQueryBuilder("post")
          .leftJoinAndSelect("post.user", "user")
          .where("post.userId IN (:...ids)", { ids: followingIds })
          .orderBy("post.createdAt", "DESC")
          .getMany();
      }
      return res.json(posts);
    } catch (error) {
      console.error("Get feed error:", error);
      return res.status(500).json({ message: "Internal error" });
    }
  }

  static async getPostById(req: AuthRequest, res: Response): Promise<Response> {
    try {
      const idParam = req.params.id;
      const postId = parseIdParam(idParam);
      if (postId === null) {
        return res.status(400).json({ message: "Invalid post id" });
      }
      const postRepo = AppDataSource.getRepository(Post);
      const post = await postRepo.findOne({
        where: { id: postId },
        relations: ["user", "comments", "comments.user"],
      });
      if (!post) return res.status(404).json({ message: "Post not found" });
      return res.json(post);
    } catch (error) {
      console.error("Get post by id error:", error);
      return res.status(500).json({ message: "Internal error" });
    }
  }

  static async deletePost(req: AuthRequest, res: Response): Promise<Response> {
    try {
      const userId = req.userId!;
      const idParam = req.params.id;
      const postId = parseIdParam(idParam);
      if (postId === null) {
        return res.status(400).json({ message: "Invalid post id" });
      }
      const postRepo = AppDataSource.getRepository(Post);
      const post = await postRepo.findOne({ where: { id: postId } });
      if (!post) return res.status(404).json({ message: "Post not found" });
      if (post.userId !== userId) return res.status(403).json({ message: "Not your post" });
      const originalFull = path.join(process.cwd(), post.originalPhotoPath);
      const previewFull = path.join(process.cwd(), post.previewPhotoPath);
      await fs.unlink(originalFull).catch(() => {});
      await fs.unlink(previewFull).catch(() => {});
      await postRepo.remove(post);
      return res.json({ message: "Post deleted" });
    } catch (error) {
      console.error("Delete post error:", error);
      return res.status(500).json({ message: "Internal error" });
    }
  }

  static async likePost(req: AuthRequest, res: Response): Promise<Response> {
    try {
      const userId = req.userId!;
      const idParam = req.params.id;
      const postId = typeof idParam === 'string' ? parseInt(idParam, 10) : parseInt(idParam[0], 10);
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post id" });
      }

      console.log(`[LIKE] Attempt: userId=${userId}, postId=${postId}`);

      // Диагностика: проверим существование пользователя
      const userRepo = AppDataSource.getRepository(User);
      const userExists = await userRepo.findOne({ where: { id: userId } });
      if (!userExists) {
        console.log(`[LIKE] User ${userId} not found in DB`);
        return res.status(404).json({ message: `User ${userId} not found` });
      }

      // Диагностика: проверим существование поста
      const postRepo = AppDataSource.getRepository(Post);
      const postExists = await postRepo.findOne({ where: { id: postId } });
      if (!postExists) {
        console.log(`[LIKE] Post ${postId} not found in DB`);
        return res.status(404).json({ message: `Post ${postId} not found` });
      }

      const likeRepo = AppDataSource.getRepository(Like);
      const existing = await likeRepo.findOne({ where: { userId, postId } });
      if (existing) {
        return res.status(409).json({ message: "Already liked" });
      }

      const like = likeRepo.create({ userId, postId });
      await likeRepo.save(like);
      console.log(`[LIKE] Success: user ${userId} liked post ${postId}`);

      if (postExists.userId !== userId) {
        const notifRepo = AppDataSource.getRepository(Notification);
        const notif = notifRepo.create({
          userId: postExists.userId,
          type: "like",
          relatedUserId: userId,
          relatedPostId: postId,
        });
        await notifRepo.save(notif);
      }
      return res.status(201).json({ message: "Liked" });
    } catch (error) {
      console.error("[LIKE] Error:", error);
      return res.status(500).json({ message: "Internal error" });
    }
  }

  static async unlikePost(req: AuthRequest, res: Response): Promise<Response> {
    try {
      const userId = req.userId!;
      const idParam = req.params.id;
      const postId = parseIdParam(idParam);
      if (postId === null) {
        return res.status(400). json({ message: "Invalid post id" });
      }
      const likeRepo = AppDataSource.getRepository(Like);
      await likeRepo.delete({ userId, postId });
      return res.json({ message: "Unliked" });
    } catch (error) {
      console.error("Unlike post error:", error);
      return res.status(500).json({ message: "Internal error" });
    }
  }

  static async favoritePost(req: AuthRequest, res: Response): Promise<Response> {
    try {
      const userId = req.userId!;
      const idParam = req.params.id;
      const postId = parseIdParam(idParam);
      if (postId === null) {
        return res.status(400).json({ message: "Invalid post id" });
      }
      const favRepo = AppDataSource.getRepository(Favorite);
      const existing = await favRepo.findOne({ where: { userId, postId } });
      if (existing) {
        return res.status(409).json({ message: "Already in favorites" });
      }
      const fav = favRepo.create({ userId, postId });
      await favRepo.save(fav);
      return res.status(201).json({ message: "Added to favorites" });
    } catch (error) {
      console.error("Favorite post error:", error);
      return res.status(500).json({ message: "Internal error" });
    }
  }

  static async unfavoritePost(req: AuthRequest, res: Response): Promise<Response> {
    try {
      const userId = req.userId!;
      const idParam = req.params.id;
      const postId = parseIdParam(idParam);
      if (postId === null) {
        return res.status(400).json({ message: "Invalid post id" });
      }
      const favRepo = AppDataSource.getRepository(Favorite);
      await favRepo.delete({ userId, postId });
      return res.json({ message: "Removed from favorites" });
    } catch (error) {
      console.error("Unfavorite post error:", error);
      return res.status(500).json({ message: "Internal error" });
    }
  }
}