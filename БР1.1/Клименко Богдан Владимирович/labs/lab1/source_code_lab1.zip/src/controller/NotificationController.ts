import { Response } from "express";
import { AuthRequest } from "../middleware/auth";
import { AppDataSource } from "../data-source";
import { Notification } from "../entity/Notification";

export class NotificationController {
  static async getNotifications(req: AuthRequest, res: Response): Promise<Response> {
    try {
      const userId = req.userId!;
      const notifRepo = AppDataSource.getRepository(Notification);
      const notifications = await notifRepo.find({
        where: { userId },
        order: { createdAt: "DESC" },
      });
      return res.json(notifications);
    } catch (error) {
      return res.status(500).json({ message: "Internal error" });
    }
  }

  static async markAsRead(req: AuthRequest, res: Response): Promise<Response> {
    try {
      const userId = req.userId!;
      const idParam = req.params.id;
      const id = typeof idParam === 'string' ? parseInt(idParam, 10) : parseInt(idParam[0], 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid notification id" });
      }
      const notifRepo = AppDataSource.getRepository(Notification);
      const notification = await notifRepo.findOne({ where: { id, userId } });
      if (!notification) return res.status(404).json({ message: "Not found" });
      notification.isRead = true;
      await notifRepo.save(notification);
      return res.json({ message: "Marked as read" });
    } catch (error) {
      return res.status(500).json({ message: "Internal error" });
    }
  }
}