import { Response } from "express";
import { AuthRequest } from "../middleware/auth";
import { AppDataSource } from "../data-source";
import { User } from "../entity/User";
import { Follow } from "../entity/Follow";
import { Notification } from "../entity/Notification";
import multer from "multer";
import path from "path";
import { ensureUploadDirs, processAvatar } from "../utils/imageProcessor";
import fs from "fs/promises";

const upload = multer({ dest: "uploads/temp/" });

export class UserController {
  static async getProfile(req: AuthRequest, res: Response): Promise<Response> {
    try {
      const userId = req.userId!;
      const userRepository = AppDataSource.getRepository(User);
      const user = await userRepository.findOne({
        where: { id: userId },
        select: ["id", "username", "email", "avatarPath", "createdAt"],
      });
      if (!user) return res.status(404).json({ message: "User not found" });
      return res.json(user);
    } catch (error) {
      return res.status(500).json({ message: "Internal error" });
    }
  }

  static async updateAvatar(req: AuthRequest, res: Response): Promise<Response> {
    return new Promise((resolve) => {
      const multerUpload = upload.single("avatar");
      multerUpload(req as any, res as any, async (err: any) => {
        if (err) {
          resolve(res.status(400).json({ message: err.message }));
          return;
        }
        const file = (req as any).file;
        if (!file) {
          resolve(res.status(400).json({ message: "No file uploaded" }));
          return;
        }
        try {
          await ensureUploadDirs();
          const ext = path.extname(file.originalname);
          const outputName = `${req.userId}_${Date.now()}${ext}.jpg`;
          const avatarUrl = await processAvatar(file.path, outputName);
          const userRepository = AppDataSource.getRepository(User);
          await userRepository.update(req.userId!, { avatarPath: avatarUrl });
          await fs.unlink(file.path).catch(() => {});
          resolve(res.json({ avatarPath: avatarUrl }));
        } catch (error) {
          resolve(res.status(500).json({ message: "Internal error" }));
        }
      });
    });
  }

  static async follow(req: AuthRequest, res: Response): Promise<Response> {
    try {
      const followerId = req.userId!;
      const followingIdParam = req.params.followingId;
      const followingId = typeof followingIdParam === 'string' ? parseInt(followingIdParam) : parseInt(followingIdParam[0]);
      if (isNaN(followingId)) {
        return res.status(400).json({ message: "Invalid user id" });
      }
      if (followerId === followingId) {
        return res.status(400).json({ message: "Cannot follow yourself" });
      }
      const followRepo = AppDataSource.getRepository(Follow);
      const existing = await followRepo.findOne({
        where: { followerId, followingId },
      });
      if (existing) {
        return res.status(409).json({ message: "Already following" });
      }
      const follow = followRepo.create({ followerId, followingId });
      await followRepo.save(follow);
      const notificationRepo = AppDataSource.getRepository(Notification);
      const notification = notificationRepo.create({
        userId: followingId,
        type: "follow",
        relatedUserId: followerId,
      });
      await notificationRepo.save(notification);
      return res.status(201).json({ message: "Followed" });
    } catch (error) {
      return res.status(500).json({ message: "Internal error" });
    }
  }

  static async unfollow(req: AuthRequest, res: Response): Promise<Response> {
    try {
      const followerId = req.userId!;
      const followingIdParam = req.params.followingId;
      const followingId = typeof followingIdParam === 'string' ? parseInt(followingIdParam) : parseInt(followingIdParam[0]);
      if (isNaN(followingId)) {
        return res.status(400).json({ message: "Invalid user id" });
      }
      const followRepo = AppDataSource.getRepository(Follow);
      await followRepo.delete({ followerId, followingId });
      return res.json({ message: "Unfollowed" });
    } catch (error) {
      return res.status(500).json({ message: "Internal error" });
    }
  }
}