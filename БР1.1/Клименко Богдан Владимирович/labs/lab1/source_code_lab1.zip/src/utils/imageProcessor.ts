import sharp from "sharp";
import path from "path";
import fs from "fs/promises";

const uploadsDir = path.resolve(process.cwd(), "uploads");

// Гарантируем существование папок
export async function ensureUploadDirs() {
  const dirs = ["avatars", "posts", "comment-photos"];
  for (const dir of dirs) {
    const fullPath = path.join(uploadsDir, dir);
    await fs.mkdir(fullPath, { recursive: true });
  }
}

// Обработка аватара: квадрат 200x200
export async function processAvatar(filePath: string, outputFileName: string): Promise<string> {
  const outputPath = path.join(uploadsDir, "avatars", outputFileName);
  await sharp(filePath)
    .resize(200, 200, { fit: "cover" })
    .jpeg({ quality: 85 })
    .toFile(outputPath);
  return `/uploads/avatars/${outputFileName}`;
}

// Обработка поста: создаём превью (ширина 1200px) и сохраняем оригинал
export async function processPostPhoto(filePath: string, baseName: string): Promise<{ originalPath: string; previewPath: string }> {
  const originalName = `original_${baseName}.jpg`;
  const previewName = `preview_${baseName}.jpg`;
  const originalOutput = path.join(uploadsDir, "posts", originalName);
  const previewOutput = path.join(uploadsDir, "posts", previewName);
  // Оригинал: просто копируем (можно пережать, но для высокого разрешения оставим как есть)
  await sharp(filePath).jpeg({ quality: 95 }).toFile(originalOutput);
  // Превью: ширина 1200, качество 85
  await sharp(filePath)
    .resize(1200, null, { withoutEnlargement: true })
    .jpeg({ quality: 85 })
    .toFile(previewOutput);
  return {
    originalPath: `/uploads/posts/${originalName}`,
    previewPath: `/uploads/posts/${previewName}`,
  };
}

// Обработка фото комментария: макс. размер ~4 Мп (ширина 2560, качество 95)
export async function processCommentPhoto(filePath: string, outputFileName: string): Promise<string> {
  const outputPath = path.join(uploadsDir, "comment-photos", outputFileName);
  await sharp(filePath)
    .resize(2560, 2560, { fit: "inside", withoutEnlargement: true })
    .jpeg({ quality: 95 })
    .toFile(outputPath);
  return `/uploads/comment-photos/${outputFileName}`;
}