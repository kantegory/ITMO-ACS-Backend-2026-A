import { Router } from "express";
import { NotificationController } from "../controller/NotificationController";
import { authenticate } from "../middleware/auth";

const router = Router();

router.get("/", authenticate, NotificationController.getNotifications);
router.put("/:id/read", authenticate, NotificationController.markAsRead);

export default router;