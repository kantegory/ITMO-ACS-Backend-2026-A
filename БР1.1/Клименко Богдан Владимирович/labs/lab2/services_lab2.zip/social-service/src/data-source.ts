import "reflect-metadata";
import { DataSource } from "typeorm";
import path from "path";
import { Follow } from "./entity/Follow";
import { Notification } from "./entity/Notification";

export const AppDataSource = new DataSource({
  type: "sqlite",
  database: path.join(__dirname, "../social.sqlite"),
  synchronize: true,
  logging: false,
  entities: [Follow, Notification],
  migrations: [],
  subscribers: [],
});