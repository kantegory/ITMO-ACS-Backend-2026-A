import "reflect-metadata";
import { DataSource } from "typeorm";
import path from "path";
import { Post } from "./entity/Post";
import { Like } from "./entity/Like";
import { Favorite } from "./entity/Favorite";

export const AppDataSource = new DataSource({
  type: "sqlite",
  database: path.join(__dirname, "../post.sqlite"),
  synchronize: true,
  logging: false,
  entities: [Post, Like, Favorite],
  migrations: [],
  subscribers: [],
});