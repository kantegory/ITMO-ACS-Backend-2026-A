import "reflect-metadata";
import { DataSource } from "typeorm";
import path from "path";
import { Comment } from "./entity/Comment";

export const AppDataSource = new DataSource({
  type: "sqlite",
  database: path.join(__dirname, "../comment.sqlite"),
  synchronize: true,
  logging: false,
  entities: [Comment],
  migrations: [],
  subscribers: [],
});